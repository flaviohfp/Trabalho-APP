
        package hotel;

// Importação das bibliotecas necessárias para a interface gráfica (JavaFX), manipulação de banco de dados (SQL), e gerenciamento de datas
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

// Classe principal que implementa a aplicação JavaFX para o sistema de gerenciamento de hotel
public class HotelApp extends Application {
    // Variáveis de instância para gerenciar o estado da aplicação
    private Stage window; // Janela principal da aplicação
    private int usuarioLogadoId = -1; // ID do usuário logado, inicializado como -1 (nenhum usuário logado)
    private int reservaId = -1; // ID da reserva atual, inicializado como -1 (nenhuma reserva selecionada)
    private double valorQuartoSelecionado = 0.0; // Valor total do quarto selecionado
    private double valorPratosSelecionados = 0.0; // Valor total dos pratos selecionados no cardápio
    private String quartoSelecionado = ""; // Número do quarto selecionado
    private List<Integer> pratosSelecionadosIds = new ArrayList<>(); // Lista de IDs dos pratos selecionados
    private Label lblValorTotal = new Label("Valor Total: R$0.00"); // Label para exibir o valor total da reserva
    private Scene telaInicial, telaLogin, telaCadastro; // Cenas principais da aplicação

    // Método principal para iniciar a aplicação JavaFX
    public static void main(String[] args) {
        launch(args);
    }

    // -------------------- Conexão com Banco de Dados --------------------
    // Método para estabelecer conexão com o banco de dados PostgreSQL
    private Connection conectar() {
        try {
            return DriverManager.getConnection(
                    "jdbc:postgresql://localhost:5432/Hotel_db",
                    "postgres",
                    "Flavin7."
            );
        } catch (SQLException e) {
            // Exibe um alerta em caso de falha na conexão com o banco
            Alert alert = new Alert(Alert.AlertType.ERROR, "Erro ao conectar ao banco! Verifique se o PostgreSQL está rodando.");
            estilizarAlerta(alert);
            alert.showAndWait();
            return null;
        }
    }

    // Método para estilizar alertas exibidos na aplicação
    private void estilizarAlerta(Alert alert) {
        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.setStyle("-fx-background-color: #e0f7fa; -fx-font-family: Arial; -fx-font-size: 14px;");
        dialogPane.lookupButton(ButtonType.OK).setStyle(
                "-fx-background-color: #00796b; -fx-text-fill: white; -fx-background-radius: 10;"
        );
    }

    // Método principal da aplicação JavaFX, inicializa a janela e as telas
    @Override
    public void start(Stage primaryStage) {
        window = primaryStage;
        criarTelaLogin(); // Cria a tela de login
        criarTelaCadastro(); // Cria a tela de cadastro
        criarTelaInicial(); // Cria a tela inicial

        window.setScene(telaInicial); // Define a tela inicial como a cena inicial
        window.setTitle("EasyRoom - Hotel"); // Define o título da janela
        window.setResizable(false); // Impede redimensionamento da janela
        window.show(); // Exibe a janela
        window.centerOnScreen(); // Centraliza a janela na tela
    }

    // -------------------- Tela Inicial --------------------
    // Método para criar a tela inicial da aplicação
    private void criarTelaInicial() {
        VBox layout = new VBox(20);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(30));
        layout.setStyle("-fx-background-color: linear-gradient(to bottom, #b2ebf2, #e0f7fa);");

        // Cria o título da tela inicial
        Label titulo = new Label("EasyRoom Hotel");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 32));
        titulo.setTextFill(Color.web("#00796b"));

        // Cria botões da tela inicial
        Button btnLogin = criarBotao("Login", "Acesse sua conta");
        Button btnReserva = criarBotao(possuiReserva(usuarioLogadoId) ? "Editar Reserva" : "Fazer Reserva", "Gerencie suas reservas");
        Button btnVerQuartos = criarBotao("Ver Quartos", "Explore nossos quartos");
        Button btnSair = criarBotao("Sair", "Fechar o aplicativo");

        // Organiza os botões em um layout vertical
        VBox botoes = new VBox(15, btnLogin, btnReserva, btnVerQuartos, btnSair);
        botoes.setAlignment(Pos.CENTER);

        // Adiciona elementos ao layout principal
        layout.getChildren().addAll(titulo, new Separator(), botoes);
        if (usuarioLogadoId == -1) {
            btnReserva.setVisible(false); // Oculta o botão de reserva se não houver usuário logado
        }

        // Define ações para os botões
        btnLogin.setOnAction(e -> window.setScene(telaLogin));
        btnReserva.setOnAction(e -> window.setScene(possuiReserva(usuarioLogadoId) ? telaEditarReserva() : telaReserva()));
        btnVerQuartos.setOnAction(e -> mostrarQuartos());
        btnSair.setOnAction(e -> window.close());

        telaInicial = new Scene(layout, 800, 600);
    }

    // Método para criar botões estilizados com tooltip
    private Button criarBotao(String texto, String tooltip) {
        Button btn = new Button(texto);
        btn.setPrefWidth(250);
        btn.setStyle(
                "-fx-background-color: #00796b; -fx-text-fill: white; -fx-font-size: 16; " +
                        "-fx-background-radius: 15; -fx-padding: 10; -fx-font-family: Arial; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 5, 0, 0, 2);"
        );
        btn.setOnMouseEntered(e -> btn.setStyle(
                "-fx-background-color: #004d40; -fx-text-fill: white; -fx-font-size: 16; " +
                        "-fx-background-radius: 15; -fx-padding: 10; -fx-font-family: Arial; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.5), 8, 0, 0, 3);"
        ));
        btn.setOnMouseExited(e -> btn.setStyle(
                "-fx-background-color: #00796b; -fx-text-fill: white; -fx-font-size: 16; " +
                        "-fx-background-radius: 15; -fx-padding: 10; -fx-font-family: Arial; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 5, 0, 0, 2);"
        ));
        if (tooltip != null) {
            btn.setTooltip(new Tooltip(tooltip));
        }
        return btn;
    }

    // Método para verificar se o usuário possui uma reserva ativa
    private boolean possuiReserva(int usuarioId) {
        if (usuarioId == -1) return false;
        try (Connection con = conectar()) {
            PreparedStatement stmt = con.prepareStatement("SELECT COUNT(*) FROM reservas WHERE usuario_id = ?");
            stmt.setInt(1, usuarioId);
            ResultSet rs = stmt.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    // Método para atualizar a tela inicial após alterações no estado da aplicação
    private void atualizarTelaInicial() {
        criarTelaInicial();
        window.setScene(telaInicial);
    }

    // -------------------- Tela de Login --------------------
    // Método para criar a tela de login
    private void criarTelaLogin() {
        GridPane layout = criarGrid();
        Label titulo = new Label("Login");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        titulo.setTextFill(Color.web("#00796b"));
        layout.add(titulo, 0, 0, 2, 1);
        GridPane.setHalignment(titulo, HPos.CENTER);

        // Cria campos de entrada para email e senha
        TextField txtEmail = criarCampo(layout, "Email:", 1);
        PasswordField txtSenha = (PasswordField) criarCampo(layout, "Senha:", 2, true);
        Button btnEntrar = criarBotao("Entrar", "Acesse sua conta");
        Button btnIrCadastro = criarBotao("Criar Conta", "Registre-se no sistema");
        Button btnVoltar = criarBotao("Voltar", "Retornar à tela inicial");
        Button btnSair = criarBotao("Sair", "Fechar o aplicativo");

        // Organiza os botões em um layout horizontal
        HBox botoes = new HBox(15, btnVoltar, btnEntrar, btnIrCadastro, btnSair);
        botoes.setAlignment(Pos.CENTER);
        layout.add(botoes, 0, 3, 2, 1);

        // Define ações para os botões
        btnEntrar.setOnAction(e -> login(txtEmail.getText(), txtSenha.getText()));
        btnIrCadastro.setOnAction(e -> window.setScene(telaCadastro));
        btnVoltar.setOnAction(e -> window.setScene(telaInicial));
        btnSair.setOnAction(e -> window.close());

        telaLogin = new Scene(layout, 800, 600);
    }

    // Método para realizar o login do usuário
    private void login(String email, String senha) {
        if (email.isEmpty() || senha.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Preencha todos os campos!");
            estilizarAlerta(alert);
            alert.showAndWait();
            return;
        }
        try (Connection con = conectar()) {
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM usuarios WHERE email=? AND senha=?");
            stmt.setString(1, email);
            stmt.setString(2, senha);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                usuarioLogadoId = rs.getInt("id");
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Login realizado com sucesso!");
                estilizarAlerta(alert);
                alert.showAndWait();
                atualizarTelaInicial();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Email ou senha incorretos!");
                estilizarAlerta(alert);
                alert.showAndWait();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // -------------------- Tela de Cadastro --------------------
    // Método para criar a tela de cadastro
    private void criarTelaCadastro() {
        GridPane layout = criarGrid();
        Label titulo = new Label("Cadastro");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        titulo.setTextFill(Color.web("#00796b"));
        layout.add(titulo, 0, 0, 2, 1);
        GridPane.setHalignment(titulo, HPos.CENTER);

        // Cria campos de entrada para nome, telefone, email e senha
        TextField txtNome = criarCampo(layout, "Nome:", 1);
        TextField txtTelefone = criarCampo(layout, "Telefone:", 2);
        TextField txtEmail = criarCampo(layout, "Email:", 3);
        PasswordField txtSenha = (PasswordField) criarCampo(layout, "Senha:", 4, true);
        Button btnCadastrar = criarBotao("Cadastrar", "Registre-se no sistema");
        Button btnVoltar = criarBotao("Voltar", "Retornar à tela inicial");
        Button btnSair = criarBotao("Sair", "Fechar o aplicativo");

        // Organiza os botões em um layout horizontal
        HBox botoes = new HBox(15, btnVoltar, btnCadastrar, btnSair);
        botoes.setAlignment(Pos.CENTER);
        layout.add(botoes, 0, 5, 2, 1);

        // Define ações para os botões
        btnCadastrar.setOnAction(e -> cadastrar(txtNome.getText(), txtTelefone.getText(), txtEmail.getText(), txtSenha.getText()));
        btnVoltar.setOnAction(e -> window.setScene(telaInicial));
        btnSair.setOnAction(e -> window.close());

        telaCadastro = new Scene(layout, 800, 600);
    }

    // Método para cadastrar um novo usuário
    private void cadastrar(String nome, String telefone, String email, String senha) {
        if (nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Preencha todos os campos!");
            estilizarAlerta(alert);
            alert.showAndWait();
            return;
        }
        try (Connection con = conectar()) {
            PreparedStatement stmt = con.prepareStatement("INSERT INTO usuarios (nome, telefone, email, senha) VALUES (?,?,?,?) RETURNING id");
            stmt.setString(1, nome);
            stmt.setString(2, telefone);
            stmt.setString(3, email);
            stmt.setString(4, senha);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                usuarioLogadoId = rs.getInt("id");
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Cadastro realizado com sucesso!");
                estilizarAlerta(alert);
                alert.showAndWait();
                atualizarTelaInicial();
            }
        } catch (SQLException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Erro ao cadastrar! Verifique se o email já está em uso.");
            estilizarAlerta(alert);
            alert.showAndWait();
        }
    }

    // Método para criar um layout de grade estilizado
    private GridPane criarGrid() {
        GridPane g = new GridPane();
        g.setHgap(15);
        g.setVgap(15);
        g.setAlignment(Pos.CENTER);
        g.setPadding(new Insets(30));
        g.setStyle("-fx-background-color: #e0f7fa; -fx-font-family: Arial;");
        return g;
    }

    // Método sobrecarregado para criar campos de texto
    private TextField criarCampo(GridPane layout, String texto, int linha) {
        return (TextField) criarCampo(layout, texto, linha, false);
    }

    // Método para criar campos de texto ou senha estilizados
    private TextField criarCampo(GridPane layout, String texto, int linha, boolean senha) {
        Label lbl = new Label(texto);
        lbl.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        lbl.setTextFill(Color.web("#004d40"));
        TextField campo = senha ? new PasswordField() : new TextField();
        campo.setPrefWidth(300);
        campo.setStyle("-fx-background-color: #ffffff; -fx-border-color: #00796b; -fx-border-radius: 5; -fx-font-family: Arial;");
        layout.add(lbl, 0, linha);
        layout.add(campo, 1, linha);
        return campo;
    }

    // -------------------- Exibição de Quartos --------------------
    // Método para exibir a lista de quartos disponíveis
    private void mostrarQuartos() {
        Stage stage = new Stage();
        VBox v = new VBox(15);
        v.setPadding(new Insets(20));
        v.setAlignment(Pos.CENTER);
        Label titulo = new Label("Quartos Disponíveis");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        titulo.setTextFill(Color.web("#00796b"));
        v.getChildren().add(titulo);
        v.getChildren().add(new Separator());

        // Consulta os quartos disponíveis no banco de dados
        try (Connection con = conectar()) {
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM quartos ORDER BY numero");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String numero = rs.getString("numero");
                String tipo = rs.getString("tipo");
                double valor = rs.getDouble("valor");
                Label lbl = new Label(numero + " - " + tipo + " - R$" + String.format("%.2f", valor));
                lbl.setFont(Font.font("Arial", 14));
                v.getChildren().add(lbl);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Erro ao carregar quartos!");
            estilizarAlerta(alert);
            alert.showAndWait();
        }

        Button btnFechar = criarBotao("Fechar", "Fechar a janela");
        v.getChildren().add(new Separator());
        v.getChildren().add(btnFechar);

        btnFechar.setOnAction(e -> stage.close());

        Scene scene = new Scene(new ScrollPane(v), 600, 500);
        stage.setScene(scene);
        stage.setResizable(false);
        stage.centerOnScreen();
        stage.setTitle("Quartos - EasyRoom");
        stage.show();
    }

    // -------------------- Gerenciamento de Reservas --------------------
    // Método para criar a tela de nova reserva
    private Scene telaReserva() {
        return criarTelaReserva(false);
    }

    // Método para criar a tela de edição de reserva
    private Scene telaEditarReserva() {
        return criarTelaReserva(true);
    }

    // Método para criar a tela de reserva (nova ou edição)
    private Scene criarTelaReserva(boolean editar) {
        VBox layout = new VBox(15);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: #e0f7fa; -fx-font-family: Arial;");

        // Define o título da tela
        Label titulo = new Label(editar ? "Editar Reserva" : "Nova Reserva");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        titulo.setTextFill(Color.web("#00796b"));

        // Cria elementos da interface
        Label lblCliente = new Label("Cliente: ");
        lblCliente.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        lblCliente.setTextFill(Color.web("#004d40"));

        DatePicker dpInicio = new DatePicker(LocalDate.now());
        dpInicio.setStyle("-fx-font-family: Arial; -fx-border-color: #00796b; -fx-border-radius: 5;");
        DatePicker dpFim = new DatePicker(LocalDate.now().plusDays(1));
        dpFim.setStyle("-fx-font-family: Arial; -fx-border-color: #00796b; -fx-border-radius: 5;");

        TextField txtQuarto = new TextField();
        txtQuarto.setEditable(false);
        txtQuarto.setPrefWidth(300);
        txtQuarto.setStyle("-fx-font-family: Arial; -fx-border-color: #00796b; -fx-border-radius: 5;");

        // Cria botões da tela de reserva
        Button btnSelecionarQuarto = criarBotao("Selecionar Quarto", "Escolha um quarto");
        Button btnCardapio = criarBotao("Cardápio", "Escolha itens do cardápio");
        Button btnSalvar = criarBotao(editar ? "Atualizar Reserva" : "Confirmar Reserva", "Salvar reserva");
        Button btnExcluir = criarBotao("Excluir Reserva", "Remover reserva existente");
        Button btnVoltar = criarBotao("Voltar", "Retornar à tela inicial");
        Button btnSair = criarBotao("Sair", "Fechar o aplicativo");

        lblValorTotal = new Label("Valor Total: R$0.00");
        lblValorTotal.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        lblValorTotal.setTextFill(Color.web("#004d40"));

        // Organiza os botões em um layout horizontal
        HBox botoes = new HBox(15, btnSelecionarQuarto, btnCardapio, btnSalvar, btnExcluir, btnVoltar, btnSair);
        botoes.setAlignment(Pos.CENTER);

        // Cria labels para os campos de data e quarto
        Label lblDataInicio = new Label("Data Início:");
        lblDataInicio.setStyle("-fx-font-family: Arial; -fx-font-weight: bold; -fx-text-fill: #004d40;");

        Label lblDataFim = new Label("Data Fim:");
        lblDataFim.setStyle("-fx-font-family: Arial; -fx-font-weight: bold; -fx-text-fill: #004d40;");

        Label lblQuarto = new Label("Quarto:");
        lblQuarto.setStyle("-fx-font-family: Arial; -fx-font-weight: bold; -fx-text-fill: #004d40;");

        // Adiciona elementos ao layout principal
        layout.getChildren().addAll(
                titulo, new Separator(),
                lblCliente,
                lblDataInicio, dpInicio,
                lblDataFim, dpFim,
                lblQuarto, txtQuarto,
                botoes, new Separator(), lblValorTotal
        );

        // Carrega informações do cliente e da reserva (se for edição)
        carregarNomeCliente(lblCliente);
        if (editar) carregarReserva(txtQuarto, dpInicio, dpFim);

        // Adiciona listeners para atualizar o valor total ao mudar as datas
        dpInicio.valueProperty().addListener((obs, old, newVal) -> atualizarValorTotal(newVal, dpFim.getValue()));
        dpFim.valueProperty().addListener((obs, old, newVal) -> atualizarValorTotal(dpInicio.getValue(), newVal));

        // Define ações para os botões
        btnSelecionarQuarto.setOnAction(e -> selecionarQuarto(dpInicio, dpFim, txtQuarto));
        btnCardapio.setOnAction(e -> abrirCardapio(dpInicio, dpFim));
        btnSalvar.setOnAction(e -> salvarReserva(editar, txtQuarto, dpInicio, dpFim));
        btnExcluir.setOnAction(e -> { if (editar) excluirReserva(); });
        btnVoltar.setOnAction(e -> atualizarTelaInicial());
        btnSair.setOnAction(e -> window.close());

        return new Scene(layout, 800, 600);
    }

    // Método para carregar o nome do cliente logado
    private void carregarNomeCliente(Label lblCliente) {
        if (usuarioLogadoId == -1) return;
        try (Connection con = conectar()) {
            PreparedStatement stmt = con.prepareStatement("SELECT nome FROM usuarios WHERE id=?");
            stmt.setInt(1, usuarioLogadoId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) lblCliente.setText("Cliente: " + rs.getString("nome"));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para carregar os dados de uma reserva existente
    private void carregarReserva(TextField txtQuarto, DatePicker dpInicio, DatePicker dpFim) {
        try (Connection con = conectar()) {
            PreparedStatement stmt = con.prepareStatement(
                    "SELECT r.id, r.data_inicio, r.data_fim, q.numero, q.valor FROM reservas r JOIN quartos q ON r.quarto_id=q.id WHERE usuario_id=?");
            stmt.setInt(1, usuarioLogadoId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                reservaId = rs.getInt("id");
                dpInicio.setValue(rs.getDate("data_inicio").toLocalDate());
                dpFim.setValue(rs.getDate("data_fim").toLocalDate());
                txtQuarto.setText(rs.getString("numero"));
                valorQuartoSelecionado = rs.getDouble("valor");
                pratosSelecionadosIds.clear();
                valorPratosSelecionados = 0.0;
                PreparedStatement stmtPratos = con.prepareStatement("SELECT prato_id, valor_unitario FROM itens_reserva WHERE reserva_id=?");
                stmtPratos.setInt(1, reservaId);
                ResultSet rsPratos = stmtPratos.executeQuery();
                while (rsPratos.next()) {
                    pratosSelecionadosIds.add(rsPratos.getInt("prato_id"));
                    valorPratosSelecionados += rsPratos.getDouble("valor_unitario");
                }
                atualizarValorTotal(dpInicio.getValue(), dpFim.getValue());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para salvar ou atualizar uma reserva
    private void salvarReserva(boolean editar, TextField txtQuarto, DatePicker dpInicio, DatePicker dpFim) {
        if (txtQuarto.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Selecione um quarto!");
            estilizarAlerta(alert);
            alert.showAndWait();
            return;
        }
        if (dpInicio.getValue() == null || dpFim.getValue() == null || dpFim.getValue().isBefore(dpInicio.getValue())) {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Datas inválidas!");
            estilizarAlerta(alert);
            alert.showAndWait();
            return;
        }
        long dias = ChronoUnit.DAYS.between(dpInicio.getValue(), dpFim.getValue());
        if (dias == 0) dias = 1;
        double total = valorQuartoSelecionado * dias + valorPratosSelecionados;
        try (Connection con = conectar()) {
            if (editar) {
                // Atualiza uma reserva existente
                PreparedStatement stmt = con.prepareStatement(
                        "UPDATE reservas SET quarto_id=(SELECT id FROM quartos WHERE numero=?),data_inicio=?,data_fim=?,valor_total=? WHERE usuario_id=?");
                stmt.setString(1, txtQuarto.getText());
                stmt.setDate(2, Date.valueOf(dpInicio.getValue()));
                stmt.setDate(3, Date.valueOf(dpFim.getValue()));
                stmt.setDouble(4, total);
                stmt.setInt(5, usuarioLogadoId);
                stmt.executeUpdate();
                PreparedStatement delItens = con.prepareStatement("DELETE FROM itens_reserva WHERE reserva_id=?");
                delItens.setInt(1, reservaId);
                delItens.executeUpdate();
            } else {
                // Cria uma nova reserva
                PreparedStatement stmt = con.prepareStatement(
                        "INSERT INTO reservas (usuario_id,quarto_id,data_inicio,data_fim,valor_total) VALUES (?,(SELECT id FROM quartos WHERE numero=?),?,?,?) RETURNING id");
                stmt.setInt(1, usuarioLogadoId);
                stmt.setString(2, txtQuarto.getText());
                stmt.setDate(3, Date.valueOf(dpInicio.getValue()));
                stmt.setDate(4, Date.valueOf(dpFim.getValue()));
                stmt.setDouble(5, total);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    reservaId = rs.getInt("id");
                }
            }
            // Insere os itens do cardápio selecionados na reserva
            for (int pratoId : pratosSelecionadosIds) {
                PreparedStatement insItem = con.prepareStatement(
                        "INSERT INTO itens_reserva (reserva_id, prato_id, valor_unitario) VALUES (?, ?, (SELECT valor FROM cardapio WHERE id=?))");
                insItem.setInt(1, reservaId);
                insItem.setInt(2, pratoId);
                insItem.setInt(3, pratoId);
                insItem.executeUpdate();
            }
            Alert alert = new Alert(Alert.AlertType.INFORMATION, editar ? "Reserva atualizada com sucesso!" : "Reserva realizada com sucesso!");
            estilizarAlerta(alert);
            alert.showAndWait();
            // Reseta valores após salvar
            valorPratosSelecionados = 0.0;
            valorQuartoSelecionado = 0.0;
            pratosSelecionadosIds.clear();
            lblValorTotal.setText("Valor Total: R$0.00");
            atualizarTelaInicial();
        } catch (SQLException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Erro ao salvar reserva!");
            estilizarAlerta(alert);
            alert.showAndWait();
        }
    }

    // Método para excluir uma reserva
    private void excluirReserva() {
        try (Connection con = conectar()) {
            PreparedStatement stmt = con.prepareStatement("DELETE FROM reservas WHERE usuario_id=?");
            stmt.setInt(1, usuarioLogadoId);
            stmt.executeUpdate();
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Reserva excluída!");
            estilizarAlerta(alert);
            alert.showAndWait();
            // Reseta valores após exclusão
            valorPratosSelecionados = 0.0;
            valorQuartoSelecionado = 0.0;
            pratosSelecionadosIds.clear();
            lblValorTotal.setText("Valor Total: R$0.00");
            atualizarTelaInicial();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para atualizar o valor total exibido com base nas datas
    private void atualizarValorTotal(LocalDate inicio, LocalDate fim) {
        if (inicio == null || fim == null) return;
        long dias = ChronoUnit.DAYS.between(inicio, fim);
        if (dias == 0) dias = 1;
        lblValorTotal.setText("Valor Total: R$" + String.format("%.2f", valorQuartoSelecionado * dias + valorPratosSelecionados));
    }

    // Método para selecionar um quarto
    private void selecionarQuarto(DatePicker dpInicio, DatePicker dpFim, TextField txtQuarto) {
        Stage stage = new Stage();
        VBox v = new VBox(15);
        v.setPadding(new Insets(20));
        v.setAlignment(Pos.CENTER);
        Label titulo = new Label("Selecionar Quarto");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        titulo.setTextFill(Color.web("#00796b"));
        v.getChildren().add(titulo);
        v.getChildren().add(new Separator());

        ToggleGroup tg = new ToggleGroup();
        // Consulta os quartos disponíveis no banco de dados
        try (Connection con = conectar()) {
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM quartos ORDER BY numero");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String numero = rs.getString("numero");
                String tipo = rs.getString("tipo");
                double valor = rs.getDouble("valor");
                RadioButton rb = new RadioButton(numero + " - " + tipo + " - R$" + String.format("%.2f", valor));
                rb.setFont(Font.font("Arial", 14));
                rb.setUserData(valor);
                rb.setToggleGroup(tg);
                v.getChildren().add(rb);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Erro ao carregar quartos!");
            estilizarAlerta(alert);
            alert.showAndWait();
        }

        // Cria botões para confirmar ou fechar a seleção
        Button btnOk = criarBotao("Selecionar", "Confirmar seleção do quarto");
        Button btnFechar = criarBotao("Fechar", "Fechar a janela");
        HBox botoes = new HBox(15, btnOk, btnFechar);
        botoes.setAlignment(Pos.CENTER);
        v.getChildren().add(new Separator());
        v.getChildren().add(botoes);

        // Define ações para os botões
        btnOk.setOnAction(e -> {
            RadioButton sel = (RadioButton) tg.getSelectedToggle();
            if (sel != null) {
                quartoSelecionado = sel.getText().split(" - ")[0];
                txtQuarto.setText(quartoSelecionado);
                valorQuartoSelecionado = (double) sel.getUserData();
                atualizarValorTotal(dpInicio.getValue(), dpFim.getValue());
                stage.close();
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Selecione um quarto!");
                estilizarAlerta(alert);
                alert.showAndWait();
            }
        });
        btnFechar.setOnAction(e -> stage.close());

        Scene scene = new Scene(new ScrollPane(v), 600, 500);
        stage.setScene(scene);
        stage.setResizable(false);
        stage.centerOnScreen();
        stage.setTitle("Seleção de Quarto - EasyRoom");
        stage.show();
    }

    // Método para abrir o cardápio e selecionar itens
    private void abrirCardapio(DatePicker dpInicio, DatePicker dpFim) {
        Stage stage = new Stage();
        VBox v = new VBox(15);
        v.setPadding(new Insets(20));
        v.setAlignment(Pos.CENTER);
        Label titulo = new Label("Cardápio do Hotel");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        titulo.setTextFill(Color.web("#00796b"));
        v.getChildren().add(titulo);
        v.getChildren().add(new Separator());

        List<CheckBox> cbList = new ArrayList<>();
        // Consulta os itens do cardápio no banco de dados
        try (Connection con = conectar()) {
            PreparedStatement stmt = con.prepareStatement("SELECT * FROM cardapio ORDER BY nome");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                double valor = rs.getDouble("valor");
                CheckBox cb = new CheckBox(rs.getString("nome") + " - R$" + String.format("%.2f", valor));
                cb.setFont(Font.font("Arial", 14));
                cb.setUserData(new Object[]{id, valor});
                if (pratosSelecionadosIds.contains(id)) cb.setSelected(true);
                cbList.add(cb);
                v.getChildren().add(cb);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Erro ao carregar cardápio!");
            estilizarAlerta(alert);
            alert.showAndWait();
        }

        // Cria botões para confirmar ou fechar o cardápio
        Button btnConfirm = criarBotao("Confirmar", "Confirmar seleção do cardápio");
        Button btnFechar = criarBotao("Fechar", "Fechar a janela");
        HBox botoes = new HBox(15, btnConfirm, btnFechar);
        botoes.setAlignment(Pos.CENTER);
        v.getChildren().add(new Separator());
        v.getChildren().add(botoes);

        // Define ações para os botões
        btnConfirm.setOnAction(ev -> {
            pratosSelecionadosIds.clear();
            double total = 0;
            for (CheckBox cb : cbList) {
                if (cb.isSelected()) {
                    Object[] data = (Object[]) cb.getUserData();
                    int id = (int) data[0];
                    double val = (double) data[1];
                    total += val;
                    pratosSelecionadosIds.add(id);
                }
            }
            valorPratosSelecionados = total;
            atualizarValorTotal(dpInicio.getValue(), dpFim.getValue());
            stage.close();
        });
        btnFechar.setOnAction(e -> stage.close());

        Scene scene = new Scene(new ScrollPane(v), 600, 500);
        stage.setScene(scene);
        stage.setResizable(false);
        stage.centerOnScreen();
        stage.setTitle("Cardápio - EasyRoom");
        stage.show();
    }
}
